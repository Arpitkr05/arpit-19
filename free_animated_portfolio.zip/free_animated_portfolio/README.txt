FREE ANIMATED PORTFOLIO — QUICK START

1. Open index.html in your browser to preview the website.
2. Open index.html in a text editor (Notepad or Visual Studio Code).
3. Use Find (Ctrl+F) to replace:
   - YOUR NAME / YOURNAME with your name or creator brand.
   - your.email@example.com with your professional email.
   - Demo project titles/descriptions and YouTube links with your own projects.
   - Instagram and YouTube profile links with your own profile URLs.
4. Save the file.

PUBLISH FREE WITH GITHUB PAGES
1. Create a free account at https://github.com/
2. Create a new PUBLIC repository named exactly: yourusername.github.io
   Replace "yourusername" with your GitHub username.
3. Upload index.html into the root of the repository:
   - Open the repository, choose Add file > Upload files.
   - Drag index.html into the page and commit the changes.
4. In the repository, open Settings > Pages.
   If needed, choose Deploy from a branch, select main and /(root), then Save.
5. Wait a few minutes. Your website should be at:
   https://yourusername.github.io/
   Replace yourusername with your actual GitHub username.

FREE HOSTING NOTES
- No paid domain is required; the GitHub Pages address is free.
- The website uses external Google Fonts and Unsplash demo images, so those need an internet connection.
- Replace the sample images with images you own or have permission to use.
- Project cards currently link to YouTube's homepage; replace each href with the actual video/project URL.
- The contact button opens the visitor's email app. It is not a contact form and does not store messages.
- Keep the repository public for the standard free GitHub Pages setup.
